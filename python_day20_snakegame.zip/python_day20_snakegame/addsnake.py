from turtle import Turtle
from food import Food


class Addsnake(Turtle,Food):


    def __init__(self):
        super().__init__()

    def add(self):
        new_segment = Turtle("square")
        new_segment.color("white")
        new_segment.penup()
        new_segment.goto(food.position)

